﻿namespace Morf
{
    partial class Szerkesztoelem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button_Ok = new System.Windows.Forms.Button();
            this.button_Megse = new System.Windows.Forms.Button();
            this.szomszedsag = new System.Windows.Forms.GroupBox();
            this.szomszed9 = new System.Windows.Forms.RadioButton();
            this.szomszed12 = new System.Windows.Forms.RadioButton();
            this.szomszed6 = new System.Windows.Forms.RadioButton();
            this.szomszed3 = new System.Windows.Forms.RadioButton();
            this.szomszedsag.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(63, 27);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(260, 13);
            this.textBox1.TabIndex = 4;
            this.textBox1.Text = "Milyen szomszédság szerinti legyen a szerkesztőelem?";
            // 
            // button_Ok
            // 
            this.button_Ok.Location = new System.Drawing.Point(65, 278);
            this.button_Ok.Name = "button_Ok";
            this.button_Ok.Size = new System.Drawing.Size(97, 26);
            this.button_Ok.TabIndex = 5;
            this.button_Ok.Text = "Ok";
            this.button_Ok.UseVisualStyleBackColor = true;
            this.button_Ok.Click += new System.EventHandler(this.button_Ok_Click);
            // 
            // button_Megse
            // 
            this.button_Megse.Location = new System.Drawing.Point(226, 278);
            this.button_Megse.Name = "button_Megse";
            this.button_Megse.Size = new System.Drawing.Size(97, 26);
            this.button_Megse.TabIndex = 6;
            this.button_Megse.Text = "Mégse";
            this.button_Megse.UseVisualStyleBackColor = true;
            this.button_Megse.Click += new System.EventHandler(this.button_Megse_Click);
            // 
            // szomszedsag
            // 
            this.szomszedsag.Controls.Add(this.szomszed9);
            this.szomszedsag.Controls.Add(this.szomszed12);
            this.szomszedsag.Controls.Add(this.szomszed6);
            this.szomszedsag.Controls.Add(this.szomszed3);
            this.szomszedsag.Location = new System.Drawing.Point(65, 66);
            this.szomszedsag.Name = "szomszedsag";
            this.szomszedsag.Size = new System.Drawing.Size(258, 191);
            this.szomszedsag.TabIndex = 7;
            this.szomszedsag.TabStop = false;
            this.szomszedsag.Text = "Szomszédság:";
            // 
            // szomszed9
            // 
            this.szomszed9.AutoSize = true;
            this.szomszed9.Location = new System.Drawing.Point(34, 111);
            this.szomszed9.Name = "szomszed9";
            this.szomszed9.Size = new System.Drawing.Size(97, 17);
            this.szomszed9.TabIndex = 4;
            this.szomszed9.Text = "9 szomszédság";
            this.szomszed9.UseVisualStyleBackColor = true;
            // 
            // szomszed12
            // 
            this.szomszed12.AutoSize = true;
            this.szomszed12.Location = new System.Drawing.Point(34, 155);
            this.szomszed12.Name = "szomszed12";
            this.szomszed12.Size = new System.Drawing.Size(103, 17);
            this.szomszed12.TabIndex = 2;
            this.szomszed12.Text = "12 szomszégság";
            this.szomszed12.UseVisualStyleBackColor = true;
            // 
            // szomszed6
            // 
            this.szomszed6.AutoSize = true;
            this.szomszed6.Location = new System.Drawing.Point(34, 67);
            this.szomszed6.Name = "szomszed6";
            this.szomszed6.Size = new System.Drawing.Size(97, 17);
            this.szomszed6.TabIndex = 1;
            this.szomszed6.Text = "6 szomszédság";
            this.szomszed6.UseVisualStyleBackColor = true;
            // 
            // szomszed3
            // 
            this.szomszed3.AutoSize = true;
            this.szomszed3.Checked = true;
            this.szomszed3.Location = new System.Drawing.Point(34, 28);
            this.szomszed3.Name = "szomszed3";
            this.szomszed3.Size = new System.Drawing.Size(97, 17);
            this.szomszed3.TabIndex = 0;
            this.szomszed3.TabStop = true;
            this.szomszed3.Text = "3 szomszédság";
            this.szomszed3.UseVisualStyleBackColor = true;
            // 
            // Szerkesztoelem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(401, 338);
            this.Controls.Add(this.szomszedsag);
            this.Controls.Add(this.button_Megse);
            this.Controls.Add(this.button_Ok);
            this.Controls.Add(this.textBox1);
            this.Name = "Szerkesztoelem";
            this.Text = "Szerkesztőelem";
            this.szomszedsag.ResumeLayout(false);
            this.szomszedsag.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button_Ok;
        private System.Windows.Forms.Button button_Megse;
        private System.Windows.Forms.GroupBox szomszedsag;
        private System.Windows.Forms.RadioButton szomszed12;
        private System.Windows.Forms.RadioButton szomszed6;
        private System.Windows.Forms.RadioButton szomszed3;
        private System.Windows.Forms.RadioButton szomszed9;
    }
}