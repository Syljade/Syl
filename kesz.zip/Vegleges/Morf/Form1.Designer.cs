﻿namespace Morf
{
    partial class Morf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.szerkesztToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dilatációToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.erózióToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.algoritmusokToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nyitásToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zárásToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.morfológiaiSzűrésToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.határkivonásToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.súgóToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.súgóToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.szerkesztToolStripMenuItem,
            this.súgóToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(492, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem1,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.ShortcutKeyDisplayString = "Alt + F";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.newToolStripMenuItem.Text = "&New/Új";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl + O";
            this.openToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.openToolStripMenuItem.Text = "&Open/Megnyitás";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem1
            // 
            this.saveToolStripMenuItem1.Name = "saveToolStripMenuItem1";
            this.saveToolStripMenuItem1.ShortcutKeyDisplayString = "Ctrl + S";
            this.saveToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem1.Size = new System.Drawing.Size(212, 22);
            this.saveToolStripMenuItem1.Text = "&Save/Mentés";
            this.saveToolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl + X";
            this.exitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.exitToolStripMenuItem.Text = "E&xit/Kilépés";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // szerkesztToolStripMenuItem
            // 
            this.szerkesztToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dilatációToolStripMenuItem,
            this.erózióToolStripMenuItem,
            this.algoritmusokToolStripMenuItem});
            this.szerkesztToolStripMenuItem.Name = "szerkesztToolStripMenuItem";
            this.szerkesztToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.szerkesztToolStripMenuItem.Text = "Szerkeszt";
            // 
            // dilatációToolStripMenuItem
            // 
            this.dilatációToolStripMenuItem.Name = "dilatációToolStripMenuItem";
            this.dilatációToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl + D";
            this.dilatációToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.dilatációToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.dilatációToolStripMenuItem.Text = "Dilatáció";
            this.dilatációToolStripMenuItem.Click += new System.EventHandler(this.dilatációToolStripMenuItem_Click);
            // 
            // erózióToolStripMenuItem
            // 
            this.erózióToolStripMenuItem.Name = "erózióToolStripMenuItem";
            this.erózióToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl + E";
            this.erózióToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.erózióToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.erózióToolStripMenuItem.Text = "Erózió";
            this.erózióToolStripMenuItem.Click += new System.EventHandler(this.erózióToolStripMenuItem_Click);
            // 
            // algoritmusokToolStripMenuItem
            // 
            this.algoritmusokToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nyitásToolStripMenuItem,
            this.zárásToolStripMenuItem,
            this.morfológiaiSzűrésToolStripMenuItem,
            this.határkivonásToolStripMenuItem});
            this.algoritmusokToolStripMenuItem.Name = "algoritmusokToolStripMenuItem";
            this.algoritmusokToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.algoritmusokToolStripMenuItem.Text = "Algoritmusok";
            // 
            // nyitásToolStripMenuItem
            // 
            this.nyitásToolStripMenuItem.Name = "nyitásToolStripMenuItem";
            this.nyitásToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.nyitásToolStripMenuItem.Text = "Nyitás";
            this.nyitásToolStripMenuItem.Click += new System.EventHandler(this.nyitásToolStripMenuItem_Click);
            // 
            // zárásToolStripMenuItem
            // 
            this.zárásToolStripMenuItem.Name = "zárásToolStripMenuItem";
            this.zárásToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.zárásToolStripMenuItem.Text = "Zárás";
            this.zárásToolStripMenuItem.Click += new System.EventHandler(this.zárásToolStripMenuItem_Click);
            // 
            // morfológiaiSzűrésToolStripMenuItem
            // 
            this.morfológiaiSzűrésToolStripMenuItem.Name = "morfológiaiSzűrésToolStripMenuItem";
            this.morfológiaiSzűrésToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.morfológiaiSzűrésToolStripMenuItem.Text = "Morfológiai szűrés";
            this.morfológiaiSzűrésToolStripMenuItem.Click += new System.EventHandler(this.morfológiaiSzűrésToolStripMenuItem_Click);
            // 
            // határkivonásToolStripMenuItem
            // 
            this.határkivonásToolStripMenuItem.Name = "határkivonásToolStripMenuItem";
            this.határkivonásToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.határkivonásToolStripMenuItem.Text = "Határkivonás";
            this.határkivonásToolStripMenuItem.Click += new System.EventHandler(this.határkivonásToolStripMenuItem_Click);
            // 
            // súgóToolStripMenuItem
            // 
            this.súgóToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.súgóToolStripMenuItem1});
            this.súgóToolStripMenuItem.Name = "súgóToolStripMenuItem";
            this.súgóToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.súgóToolStripMenuItem.Text = "Súgó";
            // 
            // súgóToolStripMenuItem1
            // 
            this.súgóToolStripMenuItem1.Name = "súgóToolStripMenuItem1";
            this.súgóToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.súgóToolStripMenuItem1.Text = "Információ";
            this.súgóToolStripMenuItem1.Click += new System.EventHandler(this.súgóToolStripMenuItem1_Click);
            // 
            // Morf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 262);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Morf";
            this.Text = "Morf";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem szerkesztToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dilatációToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem erózióToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem algoritmusokToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nyitásToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zárásToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem morfológiaiSzűrésToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem súgóToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem súgóToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem határkivonásToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;

    }
}

