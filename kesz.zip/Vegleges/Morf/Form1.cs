﻿/*
 * Diplomamunka
 * Morfologiai algoritmusok harom- es hatszogmozaikon
 * Keszitette: Saliga Szilvia
 * EHA: saslaat.sze
 * Szak: Programtervezo matematikus
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Morf
{
    public partial class Morf : Form
    {
        /*
         * Valtozok/adattagok:
         * seged[] - a kep jellemzoit tarolja (formatum, meret, stb.)
         * kep[,] - a beolvasott kep tarolasara
         * ujkep[,] - a modositott kep tarolasara
         * szelesseg - a kep szelesseget tarolja
         * magassag - a kep magassagat tarolja
         * dil - akkor igaz, ha a dilatacio kerul kivalasztasra
         * ero - akkor igaz, ha az erozio kerul kivalasztasra
         * nyitas - akkor igaz, ha a nyitas kerul kivalasztasra
         * zaras - akkor igaz, ha a zaras kerul kivalasztasra
         * msz - akkor igaz, ha a morfologiai szures kerul kivalasztasra
         * hatar - akkor igaz, ha a hatarkivonas kerul kivalasztasra
         */
        public int[] seged = new int[13];
        private byte[,] kep;
        private byte[,] ujkep;
        private int szelesseg;
        private int magassag;
        public bool dil = false;
        public bool ero = false;
        public bool nyitas = false;
        public bool zaras = false;
        public bool msz = false;
        public bool hatar = false;
        public TextBox txtClipboard;

        private MainMenu myMainMenu;

        public Morf()
        {
            InitializeComponent();
        }

        /*
         * private adattagok lekerdezo es beallito metodusai
         * */
        public int Magassag
        {
            get { return this.magassag; }
            set { this.magassag = value; }
        }

        public int Szelesseg
        {
            get { return this.szelesseg; }
            set { this.szelesseg = value; }
        }

        public byte[,] Kep
        {
            get { return this.kep; }
            set { this.kep = value; }
        }

        public byte[,] UjKep
        {
            get { return this.ujkep; }
            set { this.ujkep = value; }
        }

        /*
         * a programbol valo kilepes
         */
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /*
         * uj fajl letrehozasa
         * a program megnyitja a TriHex kepszerkeszto programot
         */
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Biztosan új fájlt kíván létrehozni?", "Kérdés", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.ErrorDialog = true;
                Process.Start("TriHex.exe");
            }

            MessageBox.Show("Kérem, a fájlt a mentés után nyissa meg az open menüponttal.", "Információ");

        }

        private void dilatációToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dil = true;

            Szerkesztoelem szer = new Szerkesztoelem();
            DialogResult result = szer.ShowDialog(this);
        }

        private void erózióToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ero = true;
            Szerkesztoelem szer = new Szerkesztoelem();
            DialogResult result = szer.ShowDialog(this);
        }

        /*
         * thf formatumu fajl megnyitasa
         */
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();

            DialogResult res = dlg.ShowDialog();

            if (res == DialogResult.OK)
            {
                String file = dlg.FileName;

                FileStream fs = new FileStream(file, FileMode.Open);

                BinaryReader br = new BinaryReader(fs, Encoding.ASCII);

                try
                {
                    // a kep adatainak beolvasasa
                    for (int k = 1; k < 13; k++)
                    {
                        int i = br.ReadByte();

                        seged[k] = i;

                        if (seged[k] < 0)
                        {
                            int szam = seged[k];
                            seged[k] = 256 + szam;
                        }
                    }

                    szelesseg = seged[6] * 256 + seged[5];
                    magassag = seged[10] * 256 + seged[9];

                    kep = new byte[szelesseg + 4, magassag + 4];
                    ujkep = new byte[szelesseg + 4, magassag + 4];

                    // kep beolvasasa
                    for (int sz = 2; sz < szelesseg + 2; sz++)
                    {
                        for (int m = 2; m < magassag + 2; m++)
                        {
                            kep[sz, m] = br.ReadByte();
                        }
                        Console.WriteLine();
                    }
                }
                catch (EndOfStreamException)
                {
                    Console.WriteLine("Nem sikerült");
                }
            }
        }

        /*
         * a modositott kep mentese
         */
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SaveFileDialog sf = new SaveFileDialog();

            sf.DefaultExt = "thf";
            sf.Filter = "TriHex fájlok (*.thf) | *.thf | Minden fájl (*.*) | *.*";
            sf.AddExtension = true;
            sf.CheckPathExists = true;
            sf.OverwritePrompt = true;
            sf.ValidateNames = true;
            //sf.InitialDirectory = "C:\\";

            DialogResult res = sf.ShowDialog();

            if (sf.FileName != "")
            {

                FileStream fs = new FileStream(sf.FileName, FileMode.Create);

                BinaryWriter bw = new BinaryWriter(fs, Encoding.ASCII);

                short formatum = (int)((byte)'H' * 256 + (byte)'T');

                bw.Write(formatum);

                int haromszog = 3;

                if (seged[3] == haromszog)
                {
                    bw.Write((byte)3);
                }
                else
                {
                    bw.Write((byte)6);
                }

                bw.Write((byte)1);
                bw.Write(szelesseg);
                bw.Write(magassag);

                for (int i = 2; i < szelesseg + 2; i++)
                {
                    for (int j = 2; j < magassag + 2; j++)
                    {
                        bw.Write((byte)UjKep[i, j]);
                    }
                }

                bw.Flush();
                bw.Close();

            }
        }

        private void nyitásToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nyitas = true;
            Szerkesztoelem szer = new Szerkesztoelem();
            DialogResult result = szer.ShowDialog(this);
        }

        private void zárásToolStripMenuItem_Click(object sender, EventArgs e)
        {
            zaras = true;
            Szerkesztoelem szer = new Szerkesztoelem();
            DialogResult result = szer.ShowDialog(this);
        }

        private void morfológiaiSzűrésToolStripMenuItem_Click(object sender, EventArgs e)
        {
            msz = true;
            Szerkesztoelem szer = new Szerkesztoelem();
            DialogResult result = szer.ShowDialog(this);
        }

        private void határkivonásToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hatar = true;
            Szerkesztoelem szer = new Szerkesztoelem();
            DialogResult result = szer.ShowDialog(this);
        }

        private void súgóToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("A program alapvető morfológia műveletek elvégzésre képes.", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
