﻿/*
 * Diplomamunka
 * Morfologiai algoritmusok harom- es hatszogmozaikon
 * Keszitette: Saliga Szilvia
 * EHA: saslaat.sze
 * Szak: Programtervezo matematikus
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Morf
{
    public partial class Szerkesztoelem : Form
    {

        public Szerkesztoelem()
        {
            InitializeComponent();
        }

        private void button_Megse_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button_Ok_Click(object sender, EventArgs e)
        {
            Morf alap = (Morf)Owner;

            if (alap.dil == true)
            {
                if (szomszed3.Checked)
                {
                    szomszed3dil();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A dilatacio vegrehajtva 3-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.dil = false;
                }
                else if (szomszed6.Checked)
                {
                    szomszed6dil();
                    if (alap.seged[3] == 6)
                    {
                        MessageBox.Show("A dilatacio vegrehajtva 6-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.dil = false;
                }
                else if (szomszed9.Checked)
                {
                    szomszed9dil();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A dilatacio vegrehajtva 9-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.dil = false;
                }
                else
                {
                    szomszed12dil();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A dilatacio vegrehajtva 12-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.dil = false;
                }
            }
            else if (alap.ero == true)
            {
                if (szomszed3.Checked)
                {
                    szomszed3ero();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("Az erozio vegrehajtva 3-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.ero = false;
                }
                else if (szomszed6.Checked)
                {
                    szomszed6ero();
                    if (alap.seged[3] == 6)
                    {
                        MessageBox.Show("Az erozio vegrehajtva 6-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.ero = false;
                }
                else if (szomszed9.Checked)
                {
                    szomszed9ero();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("Az erozio vegrehajtva 9-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.ero = false;
                }
                else
                {
                    szomszed12ero();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("Az erozio vegrehajtva 12-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.ero = false;
                }
            }
            else if (alap.nyitas == true)
            {
                if (szomszed3.Checked)
                {
                    nyitas3();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A nyitas vegrehajtva 3-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.nyitas = false;
                }
                else if (szomszed6.Checked)
                {
                    nyitas6();
                    if (alap.seged[3] == 6)
                    {
                        MessageBox.Show("A nyitas vegrehajtva 6-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.nyitas = false;
                }
                else if (szomszed9.Checked)
                {
                    nyitas9();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A nyitas vegrehajtva 9-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.nyitas = false;
                }
                else
                {
                    nyitas12();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A nyitas vegrehajtva 12-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.nyitas = false;
                }
            }
            else if (alap.zaras == true)
            {
                if (szomszed3.Checked)
                {
                    zaras3();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A zaras vegrehajtva 3-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.zaras = false;
                }
                else if (szomszed6.Checked)
                {
                    zaras6();
                    if (alap.seged[3] == 6)
                    {
                        MessageBox.Show("A zaras vegrehajtva 6-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.zaras = false;
                }
                else if (szomszed9.Checked)
                {
                    zaras9();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A zaras vegrehajtva 9-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.zaras = false;
                }
                else
                {
                    zaras12();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A zaras vegrehajtva 12-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.zaras = false;
                }
            }
            else if (alap.hatar == true)
            {
                if (szomszed3.Checked)
                {
                    hatarkivonas3();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A hatarkivonas vegrehajtva 3-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.hatar = false;
                }
                else if (szomszed6.Checked)
                {
                    hatarkivonas6();
                    if (alap.seged[3] == 6)
                    {
                        MessageBox.Show("A hatarkivonas vegrehajtva 6-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.hatar = false;
                }
                else if (szomszed9.Checked)
                {
                    hatarkivonas9();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A hatarkivonas vegrehajtva 9-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.hatar = false;
                }
                else
                {
                    hatarkivonas12();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A hatarkivonas vegrehajtva 12-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.hatar = false;
                }
            }
            else if (alap.msz == true)
            {
                if (szomszed3.Checked)
                {
                    morfszures3();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A morfologiai szures vegrehajtva 3-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.msz = false;
                }
                else if (szomszed6.Checked)
                {
                    morfszures6();
                    if (alap.seged[3] == 6)
                    {
                        MessageBox.Show("A morfologiai szures vegrehajtva 6-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.msz = false;
                }
                else if (szomszed9.Checked)
                {
                    morfszures9();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A morfologiai szures vegrehajtva 9-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.msz = false;
                }
                else
                {
                    morfszures12();
                    if (alap.seged[3] == 3)
                    {
                        MessageBox.Show("A morfologiai szures vegrehajtva 12-szomszedsag szerinti szerkesztoelemmel. Kerem, mentse le a modositast!", "Információ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    alap.msz = false;
                }
            }
            this.Close();
        }

        /*
         * Dilatacio muvelet vegrehejtasa 3-szomszedsag szerinti szerkesztoelemmel
         */
        public void szomszed3dil()
        {
            Morf alap = (Morf)Owner;

            if (alap.seged[3] == 3)
            {
                //A kép
                for (int i = 0; i < alap.Szelesseg + 4; i++)
                {
                    for (int j = 0; j < alap.Magassag + 4; j++)
                    {
                        if (((i + j) % 2) == 0)
                        {
                            if (alap.Kep[i, j] != 0)
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j] = alap.Kep[i, j];
                                alap.UjKep[i, j - 1] = alap.Kep[i, j];
                            }
                        }
                        else
                        {
                            if (alap.Kep[i, j] != 0)
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j] = alap.Kep[i, j];
                                alap.UjKep[i, j + 1] = alap.Kep[i, j];
                            }
                        }
                    }
                }
            }
            else if (alap.seged[3] == 0)
            {
                MessageBox.Show("Nincs kép betöltve", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Nem alkalmazható 6szög alapú képre!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*
         * Dilatacio muvelet vegrehejtasa 6-szomszedsag szerinti szerkesztoelemmel
         */
        public void szomszed6dil()
        {
            Morf alap = (Morf)Owner;

            if (alap.seged[3] == 0)
            {
                MessageBox.Show("Nincs kép betöltve", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (alap.seged[3] == 3)
            {
                MessageBox.Show("Nem alkalmazható 3szög alapú képre!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                //A kép közepe
                for (int i = 0; i < alap.Szelesseg + 4; i++)
                {
                    for (int j = 0; j < alap.Magassag + 4; j++)
                    {
                        if (alap.Kep[i, j] != 0 && j % 2 == 0)
                        {
                            alap.UjKep[i - 1, j + 1] = alap.Kep[i, j];
                            alap.UjKep[i, j + 1] = alap.Kep[i, j];
                            alap.UjKep[i - 1, j] = alap.Kep[i, j];
                            alap.UjKep[i + 1, j] = alap.Kep[i, j];
                            alap.UjKep[i - 1, j - 1] = alap.Kep[i, j];
                            alap.UjKep[i, j - 1] = alap.Kep[i, j];
                        }

                        if (alap.Kep[i, j] != 0 && j % 2 == 1)
                        {
                            alap.UjKep[i, j + 1] = alap.Kep[i, j];
                            alap.UjKep[i + 1, j + 1] = alap.Kep[i, j];
                            alap.UjKep[i - 1, j] = alap.Kep[i, j];
                            alap.UjKep[i + 1, j] = alap.Kep[i, j];
                            alap.UjKep[i, j - 1] = alap.Kep[i, j];
                            alap.UjKep[i + 1, j - 1] = alap.Kep[i, j];
                        }
                    }
                }
            }
            
        }

        /*
         * Dilatacio muvelet vegrehejtasa 9-szomszedsag szerinti szerkesztoelemmel
         */
        public void szomszed9dil()
        {
            Morf alap = (Morf)Owner;

            if (alap.seged[3] == 0)
            {
                MessageBox.Show("Nincs kép betöltve", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (alap.seged[3] == 3)
            {
                //A kép közepe
                for (int i = 0; i < alap.Szelesseg + 4; i++)
                {
                    for (int j = 0; j < alap.Magassag + 4; j++)
                    {
                        if (((i + j) % 2) == 0)
                        {
                            if (alap.Kep[i, j] != 0)
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j + 1] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j + 1] = alap.Kep[i, j];
                                alap.UjKep[i - 2, j] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j] = alap.Kep[i, j];
                                alap.UjKep[i + 2, j] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j - 1] = alap.Kep[i, j];
                                alap.UjKep[i, j - 1] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j - 1] = alap.Kep[i, j];
                            }
                        }
                        else
                        {
                            if (alap.Kep[i, j] != 0)
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j + 1] = alap.Kep[i, j];
                                alap.UjKep[i, j + 1] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j + 1] = alap.Kep[i, j];
                                alap.UjKep[i - 2, j] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j] = alap.Kep[i, j];
                                alap.UjKep[i + 2, j] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j - 1] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j - 1] = alap.Kep[i, j];
                            }
                        }
                     }
                }
            }
            else
            {
                MessageBox.Show("Nem alkalmazható 6szög alapú képre!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*
         * Dilatacio muvelet vegrehejtasa 12-szomszedsag szerinti szerkesztoelemmel
         */
        public void szomszed12dil()
        {
            Morf alap = (Morf)Owner;

            if (alap.seged[3] == 0)
            {
                MessageBox.Show("Nincs kép betöltve", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (alap.seged[3] == 3)
            {
                //A kép közepe
                for (int i = 0; i < alap.Szelesseg + 4; i++)
                {
                    for (int j = 0; j < alap.Magassag + 4; j++)
                    {
                        if (((i + j) % 2) == 0)
                        {
                            if (alap.Kep[i, j] != 0)
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j + 1] = alap.Kep[i, j];
                                alap.UjKep[i, j + 1] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j + 1] = alap.Kep[i, j];
                                alap.UjKep[i - 2, j] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j] = alap.Kep[i, j];
                                alap.UjKep[i + 2, j] = alap.Kep[i, j];
                                alap.UjKep[i - 2, j - 1] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j - 1] = alap.Kep[i, j];
                                alap.UjKep[i, j - 1] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j - 1] = alap.Kep[i, j];
                                alap.UjKep[i + 2, j - 1] = alap.Kep[i, j];
                            }
                        }
                        else
                        {
                            if (alap.Kep[i, j] != 0)
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                                alap.UjKep[i - 2, j + 1] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j + 1] = alap.Kep[i, j];
                                alap.UjKep[i, j + 1] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j + 1] = alap.Kep[i, j];
                                alap.UjKep[i + 2, j + 1] = alap.Kep[i, j];
                                alap.UjKep[i - 2, j] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j] = alap.Kep[i, j];
                                alap.UjKep[i + 2, j] = alap.Kep[i, j];
                                alap.UjKep[i - 1, j - 1] = alap.Kep[i, j];
                                alap.UjKep[i, j - 1] = alap.Kep[i, j];
                                alap.UjKep[i + 1, j - 1] = alap.Kep[i, j];
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Nem alkalmazható 6szög alapú képre!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*
         * Erozio muvelet vegrehejtasa 3-szomszedsag szerinti szerkesztoelemmel
         */
        public void szomszed3ero()
        {
            Morf alap = (Morf)Owner;

            if (alap.seged[3] == 0)
            {
                MessageBox.Show("Nincs kép betöltve", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (alap.seged[3] == 3)
            {
                for (int i = 0; i < alap.Szelesseg + 4; i++)
                {
                    for (int j = 0; j < alap.Magassag + 4; j++)
                    {
                        if ((i + j) % 2 == 0)
                        {
                            if (alap.Kep[i, j] != 0 && alap.Kep[i - 1, j] != 0 &&
                                alap.Kep[i + 1, j] != 0 && alap.Kep[i, j - 1] != 0)
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                            }
                            
                        }
                        else
                        {
                            if (alap.Kep[i, j] != 0 && alap.Kep[i - 1, j] != 0 &&
                                alap.Kep[i + 1, j] != 0 && alap.Kep[i, j + 1] != 0)
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Nem alkalmazható 6szög alapú képre!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*
         * Erozio muvelet vegrehejtasa 6-szomszedsag szerinti szerkesztoelemmel
         */
        public void szomszed6ero()
        {
            Morf alap = (Morf)Owner;

            if (alap.seged[3] == 0)
            {
                MessageBox.Show("Nincs kép betöltve", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (alap.seged[3] == 3)
            {
                MessageBox.Show("Nem alkalmazható 3szög alapú képre!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                for (int i = 0; i < alap.Szelesseg + 4; i++)
                {
                    for (int j = 0; j < alap.Magassag + 4; j++)
                    {
                            if (alap.Kep[i, j] != 0 && alap.Kep[i - 1, j - 1] != 0 &&
                                alap.Kep[i - 1, j] != 0 && alap.Kep[i, j - 1] != 0 &&
                                alap.Kep[i, j + 1] != 0 && alap.Kep[i + 1, j - 1] != 0 &&
                                alap.Kep[i + 1, j] != 0)
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                            }

                    }
                }
            }
        }

        /*
         * Erozio muvelet vegrehejtasa 9-szomszedsag szerinti szerkesztoelemmel
         */
        public void szomszed9ero()
        {
            Morf alap = (Morf)Owner;

            if (alap.seged[3] == 0)
            {
                MessageBox.Show("Nincs kép betöltve", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (alap.seged[3] == 3)
            {
                for (int i = 0; i < alap.Szelesseg; i++)
                {
                    for (int j = 0; j < alap.Magassag; j++)
                    {
                        if ((i + j) % 2 == 0)
                        {
                            if (alap.Kep[i, j] != 0 && alap.Kep[i - 2, j] != 0 &&
                                alap.Kep[i - 1, j] != 0 && alap.Kep[i + 1, j] != 0 &&
                                alap.Kep[i + 2, j] != 0 && alap.Kep[i - 1, j + 1] != 0 &&
                                alap.Kep[i + 1, j + 1] != 0 && alap.Kep[i - 1, j - 1] != 0
                                && alap.Kep[i, j - 1] != 0 && alap.Kep[i + 1, j - 1] != 0)
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                            }
                        }
                        else
                        {
                            if (alap.Kep[i, j] != 0 && alap.Kep[i - 2, j] != 0 &&
                                alap.Kep[i - 1, j] != 0 && alap.Kep[i + 1, j] != 0 &&
                                alap.Kep[i + 2, j] != 0 && alap.Kep[i - 1, j - 1] != 0 &&
                                alap.Kep[i + 1, j - 1] != 0 && alap.Kep[i - 1, j + 1] != 0
                                && alap.Kep[i, j + 1] != 0 && alap.Kep[i + 1, j + 1] != 0)
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Nem alkalmazható 6szög alapú képre!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*
         * Erozio muvelet vegrehejtasa 12-szomszedsag szerinti szerkesztoelemmel
         */
        public void szomszed12ero()
        {
            Morf alap = (Morf)Owner;

            if (alap.seged[3] == 0)
            {
                MessageBox.Show("Nincs kép betöltve", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (alap.seged[3] == 3)
            {
                for (int i = 0; i < alap.Szelesseg; i++)
                {
                    for (int j = 0; j < alap.Magassag; j++)
                    {
                        if ((i + j) % 2 == 0)
                        {
                            if (alap.Kep[i, j] != 0 && alap.Kep[i - 2, j] != 0 &&
                                alap.Kep[i - 1, j] != 0 && alap.Kep[i + 1, j] != 0 &&
                                alap.Kep[i + 2, j] != 0 && alap.Kep[i - 1, j + 1] != 0 &&
                                alap.Kep[i, j + 1] != 0 && alap.Kep[i + 1, j + 1] != 0 &&
                                alap.Kep[i - 2, j - 1] != 0 && alap.Kep[i - 1, j - 1] != 0 &&
                                alap.Kep[i, j - 1] != 0 && alap.Kep[i + 1, j - 1] != 0 &&
                                alap.Kep[i + 2, j - 1] != 0)
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                            }
                        }
                        else
                        {
                            if (alap.Kep[i, j] != 0 && alap.Kep[i - 2, j] != 0 &&
                                alap.Kep[i - 1, j] != 0 && alap.Kep[i + 1, j] != 0 &&
                                alap.Kep[i + 2, j] != 0 && alap.Kep[i - 1, j - 1] != 0 &&
                                alap.Kep[i, j - 1] != 0 && alap.Kep[i + 1, j - 1] != 0 &&
                                alap.Kep[i - 2, j + 1] != 0 && alap.Kep[i - 1, j + 1] != 0 &&
                                alap.Kep[i, j + 1] != 0 && alap.Kep[i + 1, j + 1] != 0 &&
                                alap.Kep[i + 2, j + 1] != 0)
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Nem alkalmazható 6szög alapú képre!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*
         * Nyitas vegrehejtasa 3-szomszedsag szerinti szerkesztoelemmel
         */
        public void nyitas3()
        {
            szomszed3ero();
            szomszed3dil();
        }

        /*
        * Nyitas vegrehejtasa 6-szomszedsag szerinti szerkesztoelemmel
        */
        public void nyitas6()
        {
            szomszed6ero();
            szomszed6dil();
        }

        /*
        * Nyitas vegrehejtasa 9-szomszedsag szerinti szerkesztoelemmel
        */
        public void nyitas9()
        {
            szomszed9ero();
            szomszed9dil();
        }

        /*
        * Nyitas vegrehejtasa 12-szomszedsag szerinti szerkesztoelemmel
        */
        public void nyitas12()
        {
            szomszed12ero();
            szomszed12dil();
        }

        /*
        * Zaras vegrehejtasa 3-szomszedsag szerinti szerkesztoelemmel
        */
        public void zaras3()
        {
            szomszed3dil();
            szomszed3ero();
        }

        /*
        * Zaras vegrehejtasa 6-szomszedsag szerinti szerkesztoelemmel
        */
        public void zaras6()
        {
            szomszed6dil();
            szomszed6ero();
        }

        /*
        * Zaras vegrehejtasa 9-szomszedsag szerinti szerkesztoelemmel
        */
        public void zaras9()
        {
            szomszed9dil();
            szomszed9ero();
        }

        /*
        * Zaras vegrehajtasa 12-szomszedsag szerinti szerkesztoelemmel
        */
        public void zaras12()
        {
            szomszed12dil();
            szomszed12ero();
        }

        /*
         * Morfologiai szures vegrehajtasa 3-szomszedsag szerinti szerkesztoelemmel
        */
        public void morfszures3()
        {
            nyitas3();
            zaras3();
        }

        /*
         * Morfologiai szures vegrehajtasa 6-szomszedsag szerinti szerkesztoelemmel
        */
        public void morfszures6()
        {
            nyitas6();
            zaras6();
        }

        /*
         * Morfologiai szures vegrehajtasa 9-szomszedsag szerinti szerkesztoelemmel
        */
        public void morfszures9()
        {
            nyitas9();
            zaras9();
        }

        /*
         * Morfologiai szures vegrehajtasa 12-szomszedsag szerinti szerkesztoelemmel
        */
        public void morfszures12()
        {
            nyitas12();
            zaras12();
        }

        /*
         * Határkivonás vegrehajtasa 3-szomszedsag szerinti szerkesztoelemmel
        */
        public void hatarkivonas3()
        {
            szomszed3ero();

            Morf alap = (Morf)Owner;

            if (alap.seged[3] == 0)
            {
                MessageBox.Show("Nincs kép betöltve", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (alap.seged[3] == 3)
            {
                for (int i = 0; i < alap.Szelesseg + 4; i++)
                {
                    for (int j = 0; j < alap.Magassag + 4; j++)
                    {
                        if (alap.Kep[i, j] != 0)
                        {
                            if (alap.UjKep[i, j] != 0)
                            {
                                alap.UjKep[i, j] = 0;
                            }
                            else
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Nem alkalmazható 6szög alapú képre!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        /*
         * Határkivonás vegrehajtasa 6-szomszedsag szerinti szerkesztoelemmel
        */
        public void hatarkivonas6()
        {
            szomszed6ero();

            Morf alap = (Morf)Owner;

            if (alap.seged[3] == 0)
            {
                MessageBox.Show("Nincs kép betöltve", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (alap.seged[3] == 3)
            {
                MessageBox.Show("Nem alkalmazható 3szög alapú képre!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (alap.seged[3] == 6)
            {
                for (int i = 0; i < alap.Szelesseg + 4; i++)
                {
                    for (int j = 0; j < alap.Magassag + 4; j++)
                    {
                        if (alap.Kep[i, j] != 0)
                        {
                            if (alap.UjKep[i, j] != 0)
                            {
                                alap.UjKep[i, j] = 0;
                            }
                            else
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                            }
                        }
                    }
                }
            }

        }

        /*
         * Határkivonás vegrehajtasa 9-szomszedsag szerinti szerkesztoelemmel
        */
        public void hatarkivonas9()
        {
            szomszed9ero();

            Morf alap = (Morf)Owner;

            if (alap.seged[3] == 0)
            {
                MessageBox.Show("Nincs kép betöltve", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (alap.seged[3] == 3)
            {
                for (int i = 0; i < alap.Szelesseg + 4; i++)
                {
                    for (int j = 0; j < alap.Magassag + 4; j++)
                    {
                        if (alap.Kep[i, j] != 0)
                        {
                            if (alap.UjKep[i, j] != 0)
                            {
                                alap.UjKep[i, j] = 0;
                            }
                            else
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Nem alkalmazható 6szög alapú képre!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        /*
         * Határkivonás vegrehajtasa 12-szomszedsag szerinti szerkesztoelemmel
        */
        public void hatarkivonas12()
        {
            szomszed12ero();

            Morf alap = (Morf)Owner;

            if (alap.seged[3] == 0)
            {
                MessageBox.Show("Nincs kép betöltve", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (alap.seged[3] == 3)
            {
                for (int i = 0; i < alap.Szelesseg + 4; i++)
                {
                    for (int j = 0; j < alap.Magassag + 4; j++)
                    {
                        if (alap.Kep[i, j] != 0)
                        {
                            if (alap.UjKep[i, j] != 0)
                            {
                                alap.UjKep[i, j] = 0;
                            }
                            else
                            {
                                alap.UjKep[i, j] = alap.Kep[i, j];
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Nem alkalmazható 6szög alapú képre!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
